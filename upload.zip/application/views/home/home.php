<!-- Main Content -->
<section class="content">
	<div class="container-fluid">
		<div class="block-header">
			<div class="row clearfix">
				<div class="col-lg-5 col-md-5 col-sm-12">
					<h2>Enkripsi dan Dekripsi</h2>
					<ul class="breadcrumb padding-0">
						<li class="breadcrumb-item"><a href="<?= site_url('home');?>"><i class="zmdi zmdi-home"></i></a>
						</li>
						<li class="breadcrumb-item"><a href="javascript:void(0);">Pages</a></li>
						<li class="breadcrumb-item active">Data enkripsi</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-12">
				<div class="card">
					<div class="header mb-3">
						<h2>Data <strong>Enkripsi</strong>
							<button type="button" class="btn btn-primary btn-sm float-right" data-toggle="modal"
								data-target="#tambah">Tambah Data</button></h2>
					</div>
					<div class="body">
						<table class="table table-bordered table-striped table-hover js-basic-example dataTable">
							<thead>
								<tr>
									<th>No</th>
									<th></th>
									<th>ID</th>
									<th>Nama</th>
									<th>Alamat</th>
									<th>Tempat Lahir</th>
									<th>Tgl. Lahir</th>
									<th>Jenis Kelamin</th>
									<th>No. Telepon</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								<?php if (!empty($member)):?>
								<?php $no = 1; foreach ($member as $val):?>
								<tr>
									<td><?= $no++;?></td>
									<td>
										<button type="button" class="btn btn-primary btn-sm"
											id="<?= $val['id_member'];?>"
											onclick="getIDmember(<?= $val['id_member'];?>)" data-toggle="modal"
											data-target="#decrypt">decrypt</button>
									</td>
									<td><?= $val['id'];?></td>
									<td><?= $val['nama'];?></td>
									<td><?= $val['alamat'];?></td>
									<td><?= $val['tempat_lahir'];?></td>
									<td><?= $val['tanggal_lahir'];?></td>
									<td><?= $val['jenis_kelamin'];?></td>
									<td><?= $val['no_telp'];?></td>
									<td><button type="button"
											class="btn btn-success btn-sm"><?= $val['status'];?></button></td>
								</tr>
								<?php endforeach;?>
								<?php endif;?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<script>
	function getIDmember(id_member) {
		console.log(id_member);
		$('#id_member').val(id_member);
	};

</script>

<!-- Large Size -->
<div class="modal fade" id="decrypt" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="title" id="largeModalLabel">Dekripsi data</h4>
			</div>
			<form action="<?= site_url('home/decrytion');?>" method="post">
				<div class="modal-body">
					<p>Harap masukkan kode, untuk dekripsi data</p>
					<div class="form-group">
						<input type="text" class="form-control" name="kode" placeholder="Masukkan Kode (16 karakter)"
							minlength="16" maxlength="16" required>
						<small class="text-danger">Harap masukkan kode sepanjang 16 karakter sesuai dengan requirement
							proses enkripsi menggunakan libray AES 128</small>
						<input type="hidden" class="form-control" id="id_member" name="id_member" required>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-default btn-round waves-effect">Dekripsi</button>
					<button type="button" class="btn btn-danger btn-simple btn-round waves-effect"
						data-dismiss="modal">Batal</button>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- Large Size -->
<div class="modal fade" id="tambah" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="title" id="largeModalLabel">Tambah data enkripsi</h4>
			</div>
			<form action="<?= site_url('home/add_data');?>" method="post">
				<div class="modal-body">
					<div class="form-group">
						<label for="inputId">ID</label>
						<input type="text" class="form-control" id="inputId" name="id" placeholder="Masukkan ID"
							required>
					</div>
					<div class="form-group">
						<label for="inputNama">Nama</label>
						<input type="text" class="form-control" id="inputNama" name="nama" placeholder="Masukkan Nama"
							required>
					</div>
					<div class="form-group">
						<label for="inputAlamat">Alamat</label>
						<textarea type="text" class="form-control" id="inputAlamat" name="alamat"
							placeholder="Masukkan Alamat" rows="3" required></textarea>
					</div>
					<div class="form-group">
						<label for="inputTempatLahir">Tempat Lahir</label>
						<input type="text" class="form-control" id="inputTempatLahir" name="tempat_lahir"
							placeholder="Masukkan Tempat Lahir" required>
					</div>
					<div class="form-group">
						<label for="inputTanggalLahir">Tanggal Lahir</label>
						<input type="date" class="form-control" id="inputTanggalLahir" name="tanggal_lahir"
							placeholder="Masukkan Tanggal Lahir" required>
					</div>
					<div class="form-group">
						<label for="inputJenisKelamin">Jenis Kelamin</label><br>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="inputLakiLaki" name="jenis_kelamin" class="custom-control-input"
								value="Laki-laki">
							<label class="custom-control-label" for="inputLakiLaki">Laki-laki</label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input type="radio" id="inputPerempuan" name="jenis_kelamin" class="custom-control-input"
								value="Perempuan">
							<label class="custom-control-label" for="inputPerempuan">Perempuan</label>
						</div>
					</div>
					<div class="form-group">
						<label for="inputNomorTelepon">Nomor Telepon</label>
						<input type="number" class="form-control" id="inputNomorTelepon" name="no_telp"
							placeholder="Masukkan Nomor Telepon" required>
					</div>
					<hr>
					<div class="form-group">
						<label for="inputKode">Kode</label>
						<input type="text" class="form-control" id="inputKode" name="no_telp" minlength="16"
							maxlength="16" placeholder="Masukkan Kode (16 karakter)" required>
						<small class="text-danger">Harap masukkan kode sepanjang 16 karakter sesuai dengan requirement
							proses enkripsi menggunakan libray AES 128</small>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-default btn-round waves-effect">Tambah data</button>
					<button type="button" class="btn btn-danger btn-simple btn-round waves-effect"
						data-dismiss="modal">Batal</button>
				</div>
			</form>
		</div>
	</div>
</div>
