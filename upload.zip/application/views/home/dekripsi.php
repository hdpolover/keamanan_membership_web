<!-- Main Content -->
<section class="content">
	<div class="container-fluid">
		<div class="block-header">
			<div class="row clearfix">
				<div class="col-lg-5 col-md-5 col-sm-12">
					<h2>Dekripsi</h2>
					<ul class="breadcrumb padding-0">
						<li class="breadcrumb-item"><a href="<?= site_url('home');?>"><i class="zmdi zmdi-home"></i></a>
						</li>
						<li class="breadcrumb-item"><a href="javascript:void(0);">Pages</a></li>
						<li class="breadcrumb-item active">Data dekripsi</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="row clearfix">
			<div class="col-lg-8">
				<div class="card">
					<div class="header mb-3">
						<h2>Data <strong>Dekripsi</strong>
							<a href="<?= site_url('home');?>" class="btn btn-primary btn-sm float-right">Kembali</a>
						</h2>
					</div>
					<div class="body">
						<div class="form-group">
							<label for="inputId">ID</label>
							<input type="text" class="form-control" id="inputId" name="id" value="<?= $member->id;?>"
								readonly>
						</div>
						<div class="form-group">
							<label for="inputNama">Nama</label>
							<input type="text" class="form-control" id="inputNama" name="nama"
								value="<?= $member->nama;?>" readonly>
						</div>
						<div class="form-group">
							<label for="inputAlamat">Alamat</label>
							<textarea type="text" class="form-control" id="inputAlamat" name="alamat" rows="3" readonly><?= $member->alamat;?></textarea>
						</div>
						<div class="form-group">
							<label for="inputTempatLahir">Tempat Lahir</label>
							<input type="text" class="form-control" id="inputTempatLahir" name="tempat_lahir"
								value="<?= $member->tempat_lahir;?>" readonly>
						</div>
						<div class="form-group">
							<label for="inputTanggalLahir">Tanggal Lahir</label>
							<input type="text" class="form-control" id="inputTanggalLahir" name="tanggal_lahir"
								value="<?= date("d M Y", strtotime($member->tanggal_lahir));?>" readonly>
						</div>
						<div class="form-group">
							<label for="inputJenisKelamin">Jenis Kelamin</label>
							<input type="text" class="form-control" id="inputJenisKelamin" name="jenis_kelamin"
								value="<?= $member->jenis_kelamin;?>" readonly>
						</div>
						<div class="form-group">
							<label for="inputNomorTelepon">Nomor Telepon</label>
							<input type="number" class="form-control" id="inputNomorTelepon" name="no_telp"
								value="<?= $member->no_telp;?>" readonly>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
