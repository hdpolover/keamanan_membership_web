<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once(APPPATH.'libraries/Aes.php');

class Home extends CI_Controller
{

    // construct
    public function __construct()
    {
        parent::__construct();
        $this->load->library('encryption');
        $this->load->model(['M_home']);
    }

    // Login
    public function login()
    {
        $this->templateauth->view('login');
    }

    // process login
    public function login_process()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if ($this->M_home->cekAuth($username, $password) == true) {
            redirect('home');
        } else {
            $this->session->set_flashdata('notif_warning', 'Password atau username yang anda masukkan salah, coba lagi !');
            redirect($this->agent->referrer());
        }
    }

    // process logout
    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url());
    }

    // dashboard
    public function index()
    {        // cek apakah user sudah login
        if ($this->session->userdata('logged_in') == false || !$this->session->userdata('logged_in')) {
            if (!empty($_SERVER['QUERY_STRING'])) {
                $uri = uri_string() . '?' . $_SERVER['QUERY_STRING'];
            } else {
                $uri = uri_string();
            }
            $this->session->set_userdata('redirect', $uri);
            $this->session->set_flashdata('notif_warning', "Harap masuk ke akun anda terlebih dahulu");
            redirect('login');
        } else {
            $member = $this->M_home->get_memberAll();

            $arrMember = [];

            foreach ($member as $val) {
                $aes = new Aes($val->kode);
                
                $arrMember[$val->id_member]['id_member'] = $val->id_member;
                $arrMember[$val->id_member]['id'] = bin2hex($aes->encrypt($val->id));
                $arrMember[$val->id_member]['nama'] = bin2hex($aes->encrypt($val->nama));
                $arrMember[$val->id_member]['alamat'] = bin2hex($aes->encrypt($val->alamat));
                $arrMember[$val->id_member]['tempat_lahir'] = bin2hex($aes->encrypt($val->tempat_lahir));
                $arrMember[$val->id_member]['tanggal_lahir'] = bin2hex($aes->encrypt($val->tanggal_lahir));
                $arrMember[$val->id_member]['jenis_kelamin'] = bin2hex($aes->encrypt($val->jenis_kelamin));
                $arrMember[$val->id_member]['no_telp'] = bin2hex($aes->encrypt($val->no_telp));
                $arrMember[$val->id_member]['status'] = $val->status;
            }

            // ej(array_values($arrMember));
            $data['member'] = $arrMember;

            $this->templatefront->view('home/home', $data);
        }
    }

    // process add data's
    public function add_data()
    {       // cek apakah user sudah login
        if ($this->session->userdata('logged_in') == false || !$this->session->userdata('logged_in')) {
            if (!empty($_SERVER['QUERY_STRING'])) {
                $uri = uri_string() . '?' . $_SERVER['QUERY_STRING'];
            } else {
                $uri = uri_string();
            }
            $this->session->set_userdata('redirect', $uri);
            $this->session->set_flashdata('notif_warning', "Harap masuk ke akun anda terlebih dahulu");
            redirect('login');
        } else {
            if ($this->M_home->add_data() == true) {
                $this->session->set_flashdata('notif_success', 'Berhasil menambahkan data');
                redirect(site_url('home'));
            } else {
                $this->session->set_flashdata('notif_warning', 'Terjadi kesalahan saat menambahkan data, harap coba lagi !');
                redirect($this->agent->referrer());
            }
        }
    }

    // process encryption
    public function encryption()
    {       // cek apakah user sudah login
        if ($this->session->userdata('logged_in') == false || !$this->session->userdata('logged_in')) {
            if (!empty($_SERVER['QUERY_STRING'])) {
                $uri = uri_string() . '?' . $_SERVER['QUERY_STRING'];
            } else {
                $uri = uri_string();
            }
            $this->session->set_userdata('redirect', $uri);
            $this->session->set_flashdata('notif_warning', "Harap masuk ke akun anda terlebih dahulu");
            redirect('login');
        } else {
            $this->templatefront->view('home/home');
        }
    }

    // process decrytion
    public function decrytion()
    {       // cek apakah user sudah login
        if ($this->session->userdata('logged_in') == false || !$this->session->userdata('logged_in')) {
            if (!empty($_SERVER['QUERY_STRING'])) {
                $uri = uri_string() . '?' . $_SERVER['QUERY_STRING'];
            } else {
                $uri = uri_string();
            }
            $this->session->set_userdata('redirect', $uri);
            $this->session->set_flashdata('notif_warning', "Harap masuk ke akun anda terlebih dahulu");
            redirect('login');
        } else {
            if ($this->input->post('kode')) {
                if ($this->M_home->cek_kode($this->input->post('kode')) == true) {
                    $data['member'] = $this->M_home->get_memberData($this->input->post('id_member'));
                    $this->templatefront->view('home/dekripsi', $data);
                } else {
                    $this->session->set_flashdata('notif_warning', "Kode yang anda masukkan salah, coba lagi");
                    redirect($this->agent->referrer());
                }
            } else {
                $this->session->set_flashdata('notif_warning', "Terjadi kesalahan, harap coba lagi");
                redirect('home');
            }
        }
    }
}
